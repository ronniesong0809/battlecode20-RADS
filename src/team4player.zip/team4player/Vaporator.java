package team4player;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class Vaporator extends Building {
    public Vaporator(RobotController r) {
        super(r);
    }

    public void takeTurn() throws GameActionException {
        super.takeTurn();
        //TODO:
    }
}